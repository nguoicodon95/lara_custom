<?php

return array(

	'uri' => 'laraedit',

	'title' => 'LaraEdit',

	'terminal' => array(
		'root' 		=> app_path() . '/../',
		'password' 	=> 'secret',
		'blocked'	=> 'ssh,telnet'
	)

);
