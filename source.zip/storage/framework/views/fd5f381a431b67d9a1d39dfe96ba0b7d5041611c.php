<div class="mobile">
    <div id="bottom_hotline" class="pull-left">
    </div>
    <div id="bottom_nav" class="pull-left">
    </div>
</div>
<div id="footer_contain">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1 text-center">
                <div class="row">
                    <div class="col-md-4">
                        <img src="<?php echo e($CMSSettings['icon_sua_chua_bao_hanh']); ?>" alt="<?php echo e(isset($CMSSettings['title_col_one']) ? $CMSSettings['title_col_one'] : ''); ?>" width="85" />
                        <h4><?php echo e(isset($CMSSettings['title_col_one']) ? $CMSSettings['title_col_one'] : ''); ?></h4>
                        <div class="sumary">
                            <?php echo isset($CMSSettings['content_col_one']) ? $CMSSettings['content_col_one'] : ''; ?>

                        </div>
                        <div class="link-detail">
                            <a href="<?php echo e(isset($CMSSettings['url_page_col_one']) ? $CMSSettings['url_page_col_one'] : '#'); ?>" class="btn btn-primary btn-sm text-uppercase">Xem chi tiết</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <img src="<?php echo e($CMSSettings['icon_ho_tro_truc_tuyen']); ?>" alt="<?php echo e(isset($CMSSettings['title_col_two']) ? $CMSSettings['title_col_two'] : ''); ?>" width="85" style="padding: 13px;"/>
                        <h4><?php echo e(isset($CMSSettings['title_col_two']) ? $CMSSettings['title_col_two'] : ''); ?></h4>
                        <div class="sumary">
                            <?php echo isset($CMSSettings['content_col_two']) ? $CMSSettings['content_col_two'] : ''; ?>

                        </div>
                    </div>
                    <div class="col-md-4">
                        <img src="<?php echo e($CMSSettings['icon_lien_he']); ?>" alt="<?php echo e(isset($CMSSettings['title_col_three']) ? $CMSSettings['title_col_three'] : ''); ?>" width="85" />
                        <h4><?php echo e(isset($CMSSettings['title_col_three']) ? $CMSSettings['title_col_three'] : ''); ?></h4>
                        <div class="sumary">
                            <?php echo isset($CMSSettings['content_col_three']) ? $CMSSettings['content_col_three'] : ''; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div id="copyright" class="text-center">&copy 2017 <span class="text-uppercase">Công ty TNHH Daikin</span>.All rights reserved | Designed and Maintained by <a href="">DanangTech.com</a></div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
