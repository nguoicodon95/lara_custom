<!-- BEGIN PAGE BAR -->
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            <a href="<?php echo e(asset($adminCpAccess)); ?>">Admin panel</a>
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <span><?php echo e(isset($pageTitle) ? $pageTitle : 'Admin panel'); ?></span>
        </li>
    </ul>
    <div class="page-toolbar">
        <?php echo $__env->yieldContent('page-toolbar'); ?>
    </div>
</div>
<!-- END PAGE BAR -->

<!-- BEGIN PAGE TITLE-->
<h3 class="page-title"> <?php echo e(isset($pageTitle) ? $pageTitle : 'Admin panel'); ?>

    <small><?php echo e(isset($subPageTitle) ? $subPageTitle : ''); ?></small>
</h3>
<!-- END PAGE TITLE-->
