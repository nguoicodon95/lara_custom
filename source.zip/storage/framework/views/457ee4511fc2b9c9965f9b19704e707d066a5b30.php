<?php $__env->startSection('page-toolbar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/core/third_party/bootstrap-tagsinput/bootstrap-tagsinput.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="/admin/core/third_party/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/ckeditor/ckeditor.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/ckeditor/config.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/ckeditor/adapters/jquery.js"></script>

    <?php /*Custom field templates*/ ?>
    <?php echo $__env->make('admin._shared._custom-field-templates', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.js-ckeditor').ckeditor({

            });

            $('.js-tags-editor').tagsinput({
                'tagClass': 'label label-default'
            });

            Utility.convertTitleToSlug('.the-object-title', '.the-object-slug');

            $('.js-validate-form').validate({
                errorElement: 'span', //default input error message container
                errorClass: 'help-block help-block-error', // default input error message class
                focusInvalid: false, // do not focus the last invalid input
                ignore: "",  // validate all fields including form hidden input
                messages: {

                },
                rules: {
                    title: {
                        minlength: 2,
                        maxlength: 255,
                        required: true
                    },
                    slug: {
                        required: true,
                        minlength: 2,
                        maxlength: 255
                    },
                    description: {
                        maxlength: 255
                    }
                },

                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error'); // set error class to the control group
                },

                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
                },

                success: function (label) {
                    label.closest('.form-group').removeClass('has-error').addClass('has-success'); // set success class to the control group
                }
            });

            /*Handle custom fields*/
            Utility.handleCustomFields();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="row">
                <form class="js-validate-form" method="POST" accept-charset="utf-8" action="" novalidate>
                    <?php echo e(csrf_field()); ?>

                    <textarea name="custom_fields" id="custom_fields_container" class="hidden form-control" style="display: none !important;" cols="30" rows="10"></textarea>
                    <div class="col-md-9">
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-note font-dark"></i>
                                    <span class="caption-subject font-dark sbold uppercase">Basic information</span>
                                </div>
                                <div class="actions">

                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="form-group">
                                    <label><b>Title <span class="text-danger">(*)</span></b></label>
                                    <input required type="text" name="title" class="form-control the-object-title" value="<?php echo e(isset($object->title) ? $object->title : ''); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label><b>Friendly slug <span class="text-danger">(*)</span></b></label>
                                    <input type="text" name="slug" class="form-control the-object-slug" value="<?php echo e(isset($object->slug) ? $object->slug : ''); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label><b>Description</b></label>
                                    <textarea name="description" class="form-control" rows="5"><?php echo e(isset($object->description) ? $object->description : ''); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label><b>Tags (use for search)</b></label>
                                    <input type="text" name="tags" class="form-control js-tags-editor" value="<?php echo e(isset($object->tags) ? $object->tags : ''); ?>" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <label><b>Page template</b></label>
                                    <select name="page_template" class="form-control">
                                        <option value=""></option>
                                        <?php foreach(_getPageTemplate('ProductCategory') as $key => $row): ?>
                                            <option <?php echo e((isset($object) && $object->page_template == $row) ? 'selected="selected"' : ''); ?> value="<?php echo e($row); ?>"><?php echo e($row); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label><b>Parent category</b></label>
                                    <select name="parent_id" class="form-control">
                                        <option value=""></option>
                                        <?php echo $categoriesHtmlSrc; ?>

                                    </select>
                                </div>
                                <div class="form-group">
                                    <label><b>Content</b></label>
                                    <textarea name="content" class="form-control js-ckeditor"><?php echo e(isset($object->content) ? $object->content : ''); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="portlet light bordered">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="icon-note font-dark"></i>
                                    <span class="caption-subject font-dark sbold uppercase">Other information</span>
                                </div>
                                <div class="actions">
                                    <!--div class="btn-group btn-group-devided">
                                        <button class="btn btn-transparent btn-success btn-circle btn-sm active" type="submit">
                                            <i class="fa fa-check"></i> Save
                                        </button>
                                    </div-->
                                </div>
                            </div>
                            <div class="portlet-body">
                                <div class="form-group">
                                    <label><b>Status</b></label>
                                    <select name="status" class="form-control">
                                        <option value="1" <?php echo e((isset($object) && $object->global_status == 1) ? 'selected' : ''); ?>>Published</option>
                                        <option value="0" <?php echo e((isset($object) && $object->global_status == 0) ? 'selected' : ''); ?>>Disabled</option>
                                        <option value="2" <?php echo e((isset($object) && $object->global_status == 2) ? 'selected' : ''); ?>>Draft</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label><b>Thumbnail image</b></label>
                                    <div class="select-media-box">
                                        <button type="button" class="btn blue show-add-media-popup">Choose image</button>
                                        <div class="clearfix"></div>
                                        <a title="" class="show-add-media-popup">
                                            <img src="<?php echo e((isset($object) && trim($object->thumbnail != '')) ? '/uploads/normal/'.$object->thumbnail : '/admin/images/no-image.png'); ?>" alt="Thumbnail" class="img-responsive">
                                        </a>
                                        <input type="hidden" name="thumbnail" value="<?php echo e(isset($object->thumbnail) ? $object->thumbnail : ''); ?>" class="input-file">

                                        <input type="hidden" name="thumbnail_path"
                                                class="thumbnail-path hidden">
                                        <a title="" class="remove-image"><span>&nbsp;</span></a>
                                    </div>
                                </div>
                            </div>
                            <div class="portlet-title portlet-footer">
                                <div class="actions">
                                    <div class="btn-group btn-group-devided">
                                        <button class="btn btn-transparent btn-success active btn-circle" type="submit">
                                            <i class="fa fa-check"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
                <div class="col-md-9">
                    <?php echo isset($customFieldBoxes) ? $customFieldBoxes : ''; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>