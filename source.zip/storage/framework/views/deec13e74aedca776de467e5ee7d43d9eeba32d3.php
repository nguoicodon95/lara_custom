<div class="meta-box textarea-box" data-slug="<?php echo e(isset($fieldItem->slug) ? $fieldItem->slug : ''); ?>">
    <p>
        <label class="sbold"><?php echo e(isset($fieldItem->title) ? $fieldItem->title : ''); ?></label><br>
        <span class="font-size-13"><?php echo e(isset($fieldItem->instructions) ? $fieldItem->instructions : ''); ?></span>
    </p>
    <div class="scf-wyswyg-wrap scf-textarea-wrap">
        <script>
            $(document).ready(function () {
                CKEDITOR.replace("wyswyg_editor_field_<?php echo e($fieldItem->slug . $fieldItem->id); ?>", {
                    <?php if($options->wyswygtoolbar == 'basic'): ?>
                        toolbar: [['mode', 'Source', 'Image', 'TextColor', 'BGColor', 'Styles', 'Format', 'Font', 'FontSize', 'CreateDiv', 'PageBreak', 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', 'RemoveFormat']]
                    <?php endif; ?>
                });
            });
        </script>
            <textarea rows="3" name="wyswyg_editor_field_<?php echo e($fieldItem->slug . $fieldItem->id); ?>" id="wyswyg_editor_field_<?php echo e($fieldItem->slug . $fieldItem->id); ?>"
                      data-fieldtype="<?php echo e(isset($fieldItem->field_type) ? $fieldItem->field_type : 'wyswyg'); ?>" data-slug="<?php echo e(isset($fieldItem->slug) ? $fieldItem->slug : ''); ?>"
                      class="form-control wyswyg-editor"><?php echo isset($theMeta) ? $theMeta : ''; ?></textarea>
    </div>
</div>