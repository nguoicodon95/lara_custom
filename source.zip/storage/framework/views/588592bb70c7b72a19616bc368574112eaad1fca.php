<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <h1 class="group_title"><span><?php echo e($object->title); ?></span></h1>
    </div>
    <div class="row">
      <div class="col-md-6">
        <?php echo $object->content; ?>

      </div>
      <div class="col-md-6">
        <?php echo $__env->make('front._modules._contact-us', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>