<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    table.cart-item {
        width: 100%;
        text-align: center;
    }
    .cart-item th {
        text-align: center;
        padding: 10px;
        border: 1px solid #CFCFCF;
        font-weight: bold;
        white-space: nowrap;
        color: #000;
        vertical-align: top;
    }
    .cart-item td {
        padding: 10px;
        border: 1px solid #CFCFCF;
    }
    .order .form-control, .order .btn {
        border-radius: 0;
    }
    .order .form-control {
        margin: 22px 0;
    }
</style>
  	<section class="main-wrapper">
      <div class="order">
        <h4 class="group_title"><span>ĐẶT HÀNG THÀNH CÔNG</span></h4>
        <table class="cart-item">
            <tr>
                <th colspan=2>Sản phẩm</th>
                <th>Giá tiền</th>
                <th>Số lượng</th>
                <th>Thành tiền</th>
            </tr>
        <?php foreach($transaction->orders as $row): ?>
            <?php $product = $row->products; ?>
            <?php $item = $product->productContent; ?>
            <tr>
                <td>
                    <img src="<?php echo e(asset($item->thumbnail)); ?>" alt="<?php echo e($item->title); ?>" width="75">
                </td>
                <td>
                    <a href="<?php echo e(_getProductLink($item->slug)); ?>"><?php echo e($item->title); ?></a>
                </td>
                <td>
                    <strong><?php echo e(_formatPrice($row->amount)); ?></strong>
                </td>
                <td><strong><?php echo e($row->qty); ?></strong></td>
                <td></td>
            </tr>
        <?php endforeach; ?>
            <tr>
                <td><strong>Tổng cộng: </strong></td>
                <td></td>
                <td></td>
                <td></td>
                <td>
                    <strong><?php echo e(_formatPrice($transaction->amount)); ?></strong>
                </td>
            </tr>
        </table>


        <h4 class="group_title"></h4>
        <div class="row">
            <div class="col-md-12">
                <p>Cảm ơn bạn <?php echo e($transaction->name); ?> đã đặt hàng tại <a href="<?php echo e(URL::to('/')); ?>">cửa hàng chúng tôi</a>!</p>
                <p>Đơn hàng của bạn đã được gửi đến chúng tôi.</p>
                <p>Chúng tôi liên hệ lại với bạn để xác nhận thông tin đặt hàng.</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(asset('/')); ?>" style="color: #4a90e2; font-weight: bold;">Quay về trang chủ</a>
            </div>
        </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>