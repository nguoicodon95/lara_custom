<div class="header_container container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <!--logo-->
            <div id="logo" class="pull-left">
                <a href="/" title="" class="logo">
                    <img src="<?php echo e(isset($CMSSettings['site_logo']) ? $CMSSettings['site_logo'] : '/images/logo/logo.png'); ?>" alt="<?php echo e(isset($CMSSettings['site_title']) ? $CMSSettings['site_title'] : ''); ?>" />
                </a>
            </div>
            <!--end logo-->
            <!--top Search-->
            <div id="top_search" class="pull-left">
                <form id="search_mini_form" action="<?php echo e(route('search')); ?>" method="get">
                    <div class="form-search form-search-autocomplete">
                        <input id="search" type="text" name="q" value="" class="input-text" maxlength="128" />
                        <button class="button" id="basic-search" type="submit" title=" Tìm kiếm">
                            <i class="fa fa-search" aria-hidden="true"></i>
                        </button>
                    </div>
                </form>
            </div>
            <!--End top search-->
            <div class="cart">Giỏ hàng: <?php echo e(isset($shoppingCart['cartItems']) ? count($shoppingCart['cartItems']) : 0); ?> sản phẩm | <?php echo e(isset($shoppingCart['cartItems']) ? _formatPrice($shoppingCart['cartSubTotal']) : 0); ?></div>

            <div class="clearfix"></div>
            <?php if(isset($shoppingCart['cartItems'])): ?>
             <ul class="cd-cart-items">
                    <?php foreach($shoppingCart['cartItems'] as $item): ?>
                    <li>
                        <div class="thumb pull-left" style="line-height: 45px;">
                            <img src="<?php echo e(asset($item->thumbnail)); ?>" alt="<?php echo e($item->title); ?>" width="55">
                        </div>
                        <div class="general pull-left"><?php echo e($item->title); ?>

                            <div class="cd-price">
                                <u>Giá:</u><strong> <?php echo e(number_format($item->price)); ?><sup>₫</sup></strong>
                            </div>
                            <u>Số Lượng:</u> <?php echo e($item->quantity); ?>

                            <a id="<?php echo e($item->id); ?>" class="cd-item-remove cd-img-replace deteteElem" title="Xóa sản phẩm này">x</a>
                        </div>
                        <div class="clearfix"></div>
                    </li>
                    <?php endforeach; ?>
                    <hr>
                    <div align="center">
                        <a href="<?php echo e(route('checkout')); ?>"><u>Đi đến đặt hàng</u></a>
                    </div>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<div class="clearfix"></div>
<div class="cog_menu">
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div id="menu_area">
                    <nav id="mainmenu">
                                <?php echo isset($main_menu) ? $main_menu : ''; ?>

                                <button>MENU</button>
                                <ul class='hidden-links hidden'></ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
