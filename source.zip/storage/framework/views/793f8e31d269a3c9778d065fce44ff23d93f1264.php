<?php $__env->startSection('page-toolbar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/core/third_party/bootstrap-tagsinput/bootstrap-tagsinput.css">
    <style>
        .panel-actions .icon-trash {
            cursor: pointer;
        }

        .panel-actions .icon-trash:hover {
            color: #e94542;
        }

        .panel hr {
            margin-bottom: 10px;
        }

        .panel {
            padding-bottom: 15px;
        }

        .sort-icons {
            font-size: 21px;
            color: #ccc;
            position: relative;
            cursor: pointer;
        }

        .sort-icons:hover {
            color: #37474F;
        }

        .icon-arrow-up, .icon-arrow-down {
            margin-right: 10px;
        }

        .icon-arrow-down {
            top: 10px;
        }

        .page-title {
            margin-bottom: 0;
        }

        .new-setting {
            text-align: center;
            width: 100%;
            margin-top: 20px;
        }

        .new-setting .panel-title {
            margin: 0 auto;
            display: inline-block;
            color: #999fac;
            font-weight: lighter;
            font-size: 13px;
            background: #fff;
            width: auto;
            height: auto;
            position: relative;
            padding-right: 15px;
        }

        #toggle_options {
            clear: both;
            float: right;
            font-size: 12px;
            position: relative;
            margin-top: 15px;
            margin-right: 5px;
            margin-bottom: 10px;
            cursor: pointer;
            z-index: 9;
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            user-select: none;
        }

        textarea {
            min-height: 120px;
        }
        select.form-control {
            display: block;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="/admin/js/jsonarea.min.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/ckeditor/ckeditor.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/ckeditor/adapters/jquery.js"></script>
    <script type="text/javascript" src="/admin/core/third_party/ckeditor/config.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $('.js-tags-editor').tagsinput({
                'tagClass': 'label label-default'
            });
            $('.js-validate-form').validate({
                errorElement: 'span', //default input error message container
                errorClass: 'help-block help-block-error', // default input error message class
                focusInvalid: false, // do not focus the last invalid input
                ignore: "",  // validate all fields including form hidden input
                messages: {
                },
                rules: {
                    'email_receives_feedback': {
                        required: true,
                        email: true
                    },
                    'site_title': {
                        required: true,
                        minlength: 3
                    }
                },
                highlight: function (element) {
                    $(element).closest('.form-group').addClass('has-error'); // set error class to the control group
                },
                unhighlight: function (element) {
                    $(element).closest('.form-group').removeClass('has-error'); // set error class to the control group
                },
                success: function (label) {
                    label.closest('.form-group').removeClass('has-error').addClass('has-success'); // set success class to the control group
                }
            });
        });
    </script>
    <script>
        var myJSONArea = JSONArea(document.getElementById('options_textarea'), {
            sourceObjects: []
        });

        valid_json = false;

        myJSONArea.getElement().addEventListener('update', function (e) {
            if (e.target.value != "") {
                valid_json = e.detail.isJSON;
                console.log(valid_json)
            }
        });

        myJSONArea.getElement().addEventListener('focusout', function (e) {
            if (valid_json) {
                $('#valid_options').show();
                $('#invalid_options').hide();
                var ugly = e.target.value;
                var obj = JSON.parse(ugly);
                var pretty = JSON.stringify(obj, undefined, 4);
                document.getElementById('options_textarea').value = pretty;
            } else {
                $('#valid_options').hide();
                $('#invalid_options').show();
            }
        });
    </script>
    <script>
        $('document').ready(function () {
            $('#toggle_options').click(function () {
                $('.new-settings-options').toggle();
                if ($('#toggle_options .voyager-double-down').length) {
                    $('#toggle_options .voyager-double-down').removeClass('voyager-double-down').addClass('voyager-double-up');
                } else {
                    $('#toggle_options .voyager-double-up').removeClass('voyager-double-up').addClass('voyager-double-down');
                }
            });
        });
    </script>
    <script>
        $('document').ready(function () {
            $('.icon-trash').click(function () {
                var action = '<?php echo e(route('web.settings.delete')); ?>/' + $(this).data('id'),
                    display = $(this).data('display-name') + '/' + $(this).data('display-key');

                $('#delete_setting_title').text(display);
                $('#delete_form')[0].action = action;
                $('#delete_modal').modal('show');
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if($group_id != 4): ?>
    <form action="<?php echo e(route('web.settings',$group_id)); ?>" novalidate method="POST" enctype="multipart/form-data" class="js-validate-form">
        <?php echo e(csrf_field()); ?>

        <div class="portlet light form-fit bordered">
            <div class="portlet-title">
                <div class="caption">
                    <i class="icon-pin"></i>
                    <span class="caption-subject sbold uppercase"><?php echo e($pageTitle); ?></span>
                </div>
            </div>
            <div class="portlet-body form">
                <!-- BEGIN FORM-->
                <div class="form-horizontal form-bordered">
                    <div class="form-body">
                        <div class="panel-body">

                        <?php foreach($settings as $setting): ?>
                            <?php if($setting->type == "homepage"): ?>
                                <div class="form-group">
                                    <label class="control-label col-md-3">
                                        <?php echo e($setting->display_name); ?>

                                        <span class="help-block">Key: <?php echo e($setting->option_key); ?></span>
                                    </label>
                                    <div class="col-md-7">
                                        <select name="default_homepage" class="form-control">
                                            <?php foreach($pages as $key => $row): ?>
                                                <option value="<?php echo e($row->id); ?>" <?php echo e($setting->option_value == $row->id ? 'selected' : ''); ?>><?php echo e($row->title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            <?php elseif($setting->type == "text"): ?>
                            <div class="form-group">
                                <label class="control-label col-md-3">
                                    <?php echo e($setting->display_name); ?>

                                    <span class="help-block">Key: <?php echo e($setting->option_key); ?></span>
                                </label>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" value="<?php echo e($setting->option_value); ?>" name="<?php echo e($setting->option_key); ?>"/>
                                </div>
                                <div class="col-md-1">
                                    <i class="icon-trash"
                                        data-id="<?php echo e($setting->id); ?>"
                                        data-display-key="<?php echo e($setting->option_key); ?>"
                                        data-display-name="<?php echo e($setting->display_name); ?>"></i>
                                </div>
                            </div>
                            <?php elseif($setting->type == "password"): ?>
                            <div class="form-group">
                                <label class="control-label col-md-3">
                                    <?php echo e($setting->display_name); ?>

                                    <span class="help-block">Key: <?php echo e($setting->option_key); ?></span>
                                </label>
                                <div class="col-md-6">
                                    <input type="password" class="form-control" name="<?php echo e($setting->option_key); ?>"/>
                                </div>
                                <div class="col-md-1">
                                    <i class="icon-trash"
                                        data-id="<?php echo e($setting->id); ?>"
                                        data-display-key="<?php echo e($setting->option_key); ?>"
                                        data-display-name="<?php echo e($setting->display_name); ?>"></i>
                                </div>
                            </div>
                            <?php elseif($setting->type == "text_area"): ?>
                                <div class="form-group">
                                    <label class="control-label col-md-3">
                                        <?php echo e($setting->display_name); ?>

                                        <span class="help-block">Key: <?php echo e($setting->option_key); ?></span>
                                    </label>
                                    <div class="col-md-6">
                                        <textarea class="form-control" name="<?php echo e($setting->option_key); ?>"><?php if(isset($setting->option_value)): ?><?php echo e($setting->option_value); ?><?php endif; ?></textarea>
                                    </div>
                                </div>
                            <?php elseif($setting->type == "editor"): ?>
                                <script>
                                    $(document).ready(function () {
                                        CKEDITOR.replace("wyswyg_editor_field_<?php echo e($setting->option_key); ?>", {
                                            toolbar: [['mode', 'Source', 'Image', 'TextColor', 'BGColor', 'Styles', 'Format', 'Font', 'FontSize', 'CreateDiv', 'PageBreak', 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', 'RemoveFormat']]
                                        });
                                    });
                                </script>
                                <div class="form-group">
                                    <label class="control-label col-md-3">
                                        <?php echo e($setting->display_name); ?>

                                        <span class="help-block">Key: <?php echo e($setting->option_key); ?></span>
                                    </label>
                                    <div class="col-md-7">
                                        <textarea rows="3" name="<?php echo e($setting->option_key); ?>" id="wyswyg_editor_field_<?php echo e($setting->option_key); ?>"
                                                data-fieldtype="wyswyg"
                                                class="form-control wyswyg-editor"><?php echo $setting->option_value; ?></textarea>
                                    </div>
                                  </div>
                            <?php elseif($setting->type == "image" || $setting->type == "file"): ?>
                                <div class="form-group">
                                    <label class="control-label col-md-3"><?php echo e($setting->display_name); ?>

                                    <span class="help-block">Key: <?php echo e($setting->option_key); ?></span></label>
                                    <div class="col-md-7">
                                        <div class="select-media-box">
                                            <button type="button" class="btn blue show-add-media-popup">Choose image</button>
                                            <div class="clearfix"></div>
                                            <a title="" class="show-add-media-popup">
                                                <img src="<?php echo e((isset($setting->option_value) && trim($setting->option_value != '')) ? $setting->option_value : '/admin/images/no-image.png'); ?>" alt="Thumbnail" class="img-responsive">
                                            </a>
                                            <input type="hidden" name="<?php echo e($setting->option_key); ?>" value="<?php echo e(isset($setting->option_value) ? $setting->option_value : ''); ?>" class="input-file">
                                            <a title="" class="remove-image"><span>&nbsp;</span></a>
                                        </div>
                                    </div>
                                </div>
                            <?php elseif($setting->type == "select_dropdown"): ?>
                                <?php $options = json_decode($setting->details); ?>
                                <?php $selected_value = (isset($setting->option_value) && !empty($setting->option_value)) ? $setting->option_value : NULL; ?>
                                <select class="form-control" name="<?php echo e($setting->option_key); ?>">
                                    <?php $default = (isset($options->default)) ? $options->default : NULL; ?>
                                    <?php if(isset($options->options)): ?>
                                        <?php foreach($options->options as $index => $option): ?>
                                            <option value="<?php echo e($index); ?>" <?php if($default == $index && $selected_value === NULL): ?><?php echo e('selected="selected"'); ?><?php endif; ?> <?php if($selected_value == $index): ?><?php echo e('selected="selected"'); ?><?php endif; ?>><?php echo e($option); ?></option>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </select>

                            <?php elseif($setting->type == "radio_btn"): ?>
                                <?php $options = json_decode($setting->details); ?>
                                <?php $selected_value = (isset($setting->option_value) && !empty($setting->option_value)) ? $setting->option_value : NULL; ?>
                                <?php $default = (isset($options->default)) ? $options->default : NULL; ?>
                                <ul class="radio">
                                    <?php foreach($options as $index => $option): ?>
                                        <li>
                                            <input type="radio" id="option-<?php echo e($index); ?>" name="<?php echo e($setting->option_key); ?>"
                                                    value="<?php echo e($index); ?>" <?php if($default == $index && $selected_value === NULL): ?><?php echo e('checked'); ?><?php endif; ?> <?php if($selected_value == $index): ?><?php echo e('checked'); ?><?php endif; ?>>
                                            <label for="option-<?php echo e($index); ?>"><?php echo e($option); ?></label>
                                            <div class="check"></div>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php elseif($setting->type == "checkbox"): ?>
                                <?php $options = json_decode($setting->details); ?>
                                <?php $checked = (isset($setting->option_value) && $setting->option_value == 1) ? true : false; ?>
                                <?php if(isset($options->on) && isset($options->off)): ?>
                                    <input type="checkbox" name="<?php echo e($setting->option_key); ?>" class="toggleswitch" <?php if($checked): ?> checked <?php endif; ?> data-on="<?php echo e($options->on); ?>" data-off="<?php echo e($options->off); ?>">
                                <?php else: ?>
                                    <input type="checkbox" name="<?php echo e($setting->option_key); ?>" <?php if($checked): ?> checked <?php endif; ?> class="toggleswitch">
                                <?php endif; ?>
                            <?php elseif($setting->type == "keywords"): ?>
                                <div class="form-group">
                                    <label class="control-label col-md-3"><?php echo e($setting->display_name); ?></label>
                                    <div class="col-md-7">
                                        <input type="text" class="form-control js-tags-editor" value="<?php echo e($setting->option_value); ?>" name="<?php echo e($setting->option_key); ?>"/>
                                    </div>
                                </div>
                            <?php elseif($setting->type == "root"): ?>
                                <div class="form-group">
                                    <label class="control-label col-md-3"><?php echo e($setting->display_name); ?></label>
                                    <div class="col-md-7">
                                        <div class="md-checkbox">
                                            <input type="checkbox"
                                                    value="1"
                                                    id="<?php echo e($setting->option_key); ?>"
                                                    name="<?php echo e($setting->option_key); ?>"
                                                    <?php echo e((int)$setting->option_value == 1 ? 'checked' : ''); ?>

                                                    class="md-radiobtn">
                                            <label for="<?php echo e($setting->option_key); ?>" style="margin-bottom: 0;">
                                                <span></span>
                                                <span class="check"></span>
                                                <span class="box"></span> In construction mode
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php /* <?php if(!$loop->last): ?>
                                <hr>
                            <?php endif; ?>*/ ?>
                        <?php endforeach; ?>

                        <div class="text-right" style="padding: 15px;">
                            <button type="submit" class="btn btn-circle green font-white btn-default">
                                <i class="fa fa-check"></i> Update
                            </button>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END FORM-->
        </div>
        <div class="clearfix"></div>
    </form>

    <div class="row">
        <div class="col-md-12">
            <div class="portlet light form-fit">


                <div style="clear:both"></div>

                <div class="panel" style="margin-top:10px;">
                    <div class="panel-heading new-setting">
                        <hr>
                        <label>
                            <i class="icon-plus"></i> New Setting
                        </label>
                    </div>
                    <div class="panel-body">
                        <form action="<?php echo e(route('web.settings.create', $group_id)); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-md-4">
                                <label for="display_name">Name</label>
                                <input type="text" class="form-control" name="display_name">
                            </div>
                            <div class="col-md-4">
                                <label for="key">Key</label>
                                <input type="text" class="form-control" name="option_key">
                            </div>
                            <div class="col-md-4">
                                <label>Type</label>
                                <select name="type" class="form-control">
                                    <option value="text">Text Box</option>
                                    <option value="password">Password</option>
                                    <option value="text_area">Text Area</option>
                                    <option value="editor">Editor</option>
                                    <option value="checkbox">Check Box</option>
                                    <option value="radio_btn">Radio Button</option>
                                    <option value="select_dropdown">Select Dropdown</option>
                                    <option value="file">File</option>
                                    <option value="image">Image</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <a id="toggle_options"><i class="voyager-double-down"></i> OPTIONS</a>
                                <div class="new-settings-options">
                                    <label for="options">Options
                                        <small>(optional, only applies to certain types like dropdown box or radio button)
                                        </small>
                                    </label>
                                    <textarea name="details" id="options_textarea" class="form-control" placeholder='[{"a":"b"}]'></textarea>
                                    <div id="valid_options" class="alert-success alert" style="display:none">Valid Json</div>
                                    <div id="invalid_options" class="alert-danger alert" style="display:none">Invalid Json</div>
                                </div>
                            </div>

                            <div style="clear:both"></div>
                            <button type="submit" class="btn btn-primary pull-right new-setting-btn">
                                <i class="voyager-plus"></i> Add New Setting
                            </button>
                            <div style="clear:both"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal modal-danger fade" tabindex="-1" id="delete_modal" role="dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><i class="voyager-trash"></i>Bạn đồng ý xóa item này?</h4>
            </div>
            <div class="modal-footer">
                <form action="<?php echo e(route('web.settings.delete')); ?>" id="delete_form"
                        method="POST">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="submit" class="btn btn-danger pull-right delete-confirm"
                            value="Đồng ý xóa item này">
                </form>
                <button type="button" class="btn btn-default pull-right" data-dismiss="modal">Hủy</button>
            </div>
        </div><!-- /.modal-content -->
    </div>
<?php else: ?>
  Đây là bộ phận không thể tiếp cận, có thể ảnh hưởng đến việc chạy site
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>