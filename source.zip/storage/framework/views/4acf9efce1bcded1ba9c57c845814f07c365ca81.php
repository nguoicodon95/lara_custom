<?php $__env->startSection('css'); ?>
    <link href="/css/ubislider.min.css" rel="stylesheet" type="text/css">
    <style>
        .detail-post h1 {
            font-size: 18px;
        }

        .post.excerpt, .pr.excerpt {
          clear: both;
          margin-bottom: 30px;
          background-color: #fff;
          padding: 20px;
          border: 1px solid #cdcdcd;
        }
        .corner:before {
          content: "";
          position: absolute;
          left: -10px;
          width: 0;
          height: 0;
          border-style: solid;
          border-width: 0 0 10px 10px;
          border-color: rgba(0, 0, 0, 0) rgba(0, 0, 0, 0) rgba(0, 0, 0, 0.15) rgba(0, 0, 0, 0);
      }
      .post-date-ribbon {
          text-align: center;
          line-height: 25px;
          color: #fff;
          font-size: 12px;
          margin-top: -30px;
          position: relative;
          padding: 0 7px;
          float: left;
          background-color: #0182c6;
      }
      article header {
          margin-bottom: 0;
          float: left;
      }
      .title {
          margin-bottom: 5px;
          margin-top: 10px;
          font-size: 15px;
          line-height: 18px;
          display: inline;
      }
      .featured-thumbnail {
          float: left;
          max-width: 150px;
          width: 27.2%;
          margin-right: 10px;
          line-height: 2;
      }

      .popular_pr {
          display: block;
          background: #fff;
          padding: 10px;
      }
      .popular_pr .thumb {
          width: 30%;
          float: left;
          padding-right: 5px;
      }
      .popular_pr h2 {
          font-size: 15px;
          line-height: 18px;
      }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="/third_party/jqueryElevateZoom.js"></script>
<script src="/third_party/ubislider.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script>
        $('#slider').ubislider({
            arrowsToggle: true,
            type: 'ecommerce',
            hideArrows: true,
            autoSlideOnLastClick: true,
            modalOnClick: true,
            position: 'vertical'
        });

        (function(){

            $('#itemslider').carousel({ interval: 3000 });

            $('.carousel-showmanymoveone .item').each(function(){
                var itemToClone = $(this);

                for (var i=1;i<6;i++) {
                itemToClone = itemToClone.next();


                if (!itemToClone.length) {
                    itemToClone = $(this).siblings(':first');
                }


                itemToClone.children(':first-child').clone()
                    .addClass("cloneditem-"+(i))
                    .appendTo($(this));
                }
            });
        }());

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-7">
            <div class="ubislider-image-container left" data-ubislider="#slider" style="cursor: pointer"></div>
            <div id="slider" class="ubislider left">
                <a class="arrow prev"></a>
                <a class="arrow next"></a>
                <ul id="gal1" class="ubislider-inner">
                    <li>
                        <a>
                            <img src="<?php echo e($object->thumbnail); ?>" alt="">
                        </a>
                    </li>
                    <?php if(!empty($thumbs) && isset($thumbs)): ?>
                        <?php foreach($thumbs as $thumb): ?>
                        <li>
                            <a>
                                <img class="product-v-img" src="<?php echo e($thumb['src']); ?>">
                            </a>
                        </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="clearfix"></div>
        </div>

        <div class="col-md-5 col-md-offset-0">
            <div class="product_info">
                <h1 class="name"><?php echo e($object->title); ?></h1>
                <div>Mã sản phẩm: <?php echo e($object->sku); ?></div>
                <hr>
                <div class="price-box">
                    <span class="regular-price">
                        <?php if($object->old_price != 0): ?>
                        <span class="old-price"><?php echo e(_formatPrice($object->old_price)); ?></span>
                        <?php endif; ?>
                        <span class="price"><?php echo e(_formatPrice($object->price)); ?></span>
                    </span>
                </div>
                <div>
                    <table class="description">
                    <?php if(isset($attributes) && !empty($attributes)): ?>
                        <?php foreach($attributes as $key => $value): ?>
                            <tr>
                                <th><?php echo e($key); ?></th>
                                <td><?php echo e($value); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </table>
                </div>
                <div class="addtocart">
                    <div class="select-qty">
                        <label for="qty">Số lượng</label>
                        <select name="qty" id="qty">
                            <?php for($i = 1; $i < 7; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <a href="<?php echo e(_getAddToCartLink($object->content_id)); ?>" class="btn btn-cart pull-right">Đặt hàng</a>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <h2 class="group_title">
                <span>Thông tin chi chiết</span>
            </h2>
            <div class="dt-content">
                <?php echo $object->content; ?>

            </div>
        </div>
        <div class="col-md-4 filterbx hidden-xs">
            <h2 class="group_title">
                <span>Sản phẩm <?php echo e($object->brand->name); ?></span>
            </h2>
            <?php if(isset($product_s_brand) && !empty($product_s_brand)): ?>
              <?php foreach($product_s_brand as $r): ?>
              <article class="pr excerpt">
                  <div class="post-date-ribbon">
                      <div class="corner"></div><u>Giá:</u> <?php echo e(_formatPrice($r['price'])); ?>

                  </div>
                  <header>
                  <a href="<?php echo e(_getPostLink($r['slug'])); ?>" title="<?php echo e(isset($r['title']) ? $r['title'] : ''); ?>">
                      <div class="featured-thumbnail">
                          <img src="<?php echo e(isset($r['thumbnail']) ? $r['thumbnail'] : ''); ?>" class="attachment-ribbon-lite-featured size-ribbon-lite-featured wp-post-image" alt="<?php echo e(isset($r['title']) ? $r['title'] : ''); ?>" title="<?php echo e(isset($r['title']) ? $r['title'] : ''); ?>">
                      </div>
                  </a>
                  <h2 class="title text-center">
                      <a href="<?php echo e(_getPostLink($r['slug'])); ?>" title="<?php echo e(isset($r['title']) ? $r['title'] : ''); ?>" rel="bookmark"><?php echo e(isset($r['title']) ? $r['title'] : ''); ?></a>
                  </h2>
                  </header><!--.header-->
                  <div class="clearfix"></div>
              </article>
              <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <h2 class="group_title">
        <span>Sản phẩm cùng loại</span>
    </h2>
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="carousel carousel-showmanymoveone slide" id="itemslider">
                <div class="carousel-inner">
                <?php if(isset($same_product) && !empty($same_product)): ?>
                    <?php foreach($same_product as $k => $p): ?>
                    <?php
                        $active = '';
                        if($k == 0) {
                            $active = 'active';
                        }
                    ?>
                    <div class="item <?php echo e($active); ?>">
                        <div class="col-xs-12 col-sm-6 col-md-2">
                        <a href="<?php echo e(_getProductLink($p->slug)); ?>">
                            <img src="<?php echo e($p->thumbnail); ?>" class="img-responsive center-block">
                            <h4 class="text-center"><?php echo e($p->title); ?></h4>
                        </a>

                        <div class="price-box" align="center">
                            <span class="regular-price">
                                <?php if($p['old_price'] != 0): ?>
                                <span class="old-price"><s><?php echo e(_formatPrice($p->old_price)); ?></s></span>
                                <?php endif; ?>
                                <span class="price"><?php echo e(_formatPrice($p->price)); ?></span>
                            </span>
                        </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>

                <div id="slider-control">
                <a class="left carousel-control" href="#itemslider" data-slide="prev">
                    <img src="/images/libraries/arrow_left.png" alt="Left" class="img-responsive">
                </a>
                <a class="right carousel-control" href="#itemslider" data-slide="next">
                    <img src="/images/libraries/arrow_right.png" alt="Right" class="img-responsive">
                </a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>