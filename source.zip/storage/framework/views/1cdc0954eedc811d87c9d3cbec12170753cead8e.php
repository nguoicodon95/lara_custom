<div class="line" data-option="defaultvalue">
    <div class="col-xs-3">
        <h5>Default Value</h5>
        <p>Appears when creating a new post</p>
    </div>
    <div class="col-xs-9">
        <h5>Default Value</h5>
        <input type="text" class="form-control" placeholder="" value="<?php echo e(isset($options->defaultvalue) ? $options->defaultvalue : ''); ?>">
    </div>
    <div class="clearfix"></div>
</div>