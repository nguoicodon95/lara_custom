<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
<style>
    .post.excerpt, .pr.excerpt {
      clear: both;
      margin-bottom: 30px;
      background-color: #fff;
      padding: 20px;
      border: 1px solid #cdcdcd;
    }
    .corner:before {
      content: "";
      position: absolute;
      left: -10px;
      width: 0;
      height: 0;
      border-style: solid;
      border-width: 0 0 10px 10px;
      border-color: rgba(0, 0, 0, 0) rgba(0, 0, 0, 0) rgba(0, 0, 0, 0.15) rgba(0, 0, 0, 0);
  }
  .post-date-ribbon {
      text-align: center;
      line-height: 25px;
      color: #fff;
      font-size: 12px;
      margin-top: -30px;
      position: relative;
      padding: 0 7px;
      float: left;
      background-color: #EA141F;
  }
  article header {
      margin-bottom: 15px;
      float: left;
  }
  .title {
      margin-bottom: 5px;
      margin-top: 10px;
      font-size: 19px;
      line-height: 18px;
      clear: both;
  }
  #featured-thumbnail {
      float: left;
      max-width: 150px;
      width: 22.2%;
      margin-right: 20px;
  }
  .readMore {
      margin-top: 15px;
  }
  .readMore a {
      color: #fff;
      padding: 5px 12px;
      transition: all 0.25s linear;
      font-family: 'Monda', sans-serif;
      background-color: #EA141F;
  }

  .popular_pr {
      display: block;
      background: #fff;
      padding: 10px;
  }
  .popular_pr .thumb {
      width: 30%;
      float: left;
      padding-right: 5px;
  }
  .popular_pr h2 {
      font-size: 15px;
      line-height: 18px;
  }

  .pr .post-date-ribbon {
      background-color: #0182c6;
  }
  .pr .title {
      font-size: 15px;
  }
  .pr header {
      margin-bottom: 0;
  }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
        <div class="col-md-8">
        <?php foreach($relatedPosts as $key => $row): ?>
            <article class="post excerpt">
                <div class="post-date-ribbon">
                    <div class="corner"></div><?php echo e(isset($row->created_at) ? $row->created_at : ''); ?>

                </div>
                <header>
                <h2 class="title">
                    <a href="<?php echo e(_getPostLink($row->slug)); ?>" title="<?php echo e(isset($row->title) ? $row->title : ''); ?>" rel="bookmark"><?php echo e(isset($row->title) ? $row->title : ''); ?></a>
                </h2>
                </header><!--.header-->
                <a href="<?php echo e(_getPostLink($row->slug)); ?>" title="<?php echo e(isset($row->title) ? $row->title : ''); ?>" id="featured-thumbnail">
                    <div class="featured-thumbnail">
                        <img width="150" height="120" src="<?php echo e(isset($row->thumbnail) ? $row->thumbnail : ''); ?>" class="attachment-ribbon-lite-featured size-ribbon-lite-featured wp-post-image" alt="<?php echo e(isset($row->title) ? $row->title : ''); ?>" title="<?php echo e(isset($row->title) ? $row->title : ''); ?>" srcset="" sizes="(max-width: 150px) 100vw, 150px">
                    </div>
                </a>
                <div class="post-content">
                    <?php echo isset($row->description) ? $row->description : ''; ?>

                </div>
                <div class="readMore">
                    <a href="<?php echo e(_getPostLink($row->slug)); ?>" title="<?php echo e(isset($row->title) ? $row->title : ''); ?>">
                        Xem chi tiết</a>
                </div>
                <div class="clearfix"></div>
            </article>
        <?php endforeach; ?>
            <div align="center">
                <?php echo $relatedPosts->setPath(asset(Request::path()))->appends(Request::query())->render(); ?>

            </div>
        </div>
        <div class="col-md-4 filterbx">
            <p class="group_title"><span>Sản phẩm nổi bật</span></p>
            <?php if(isset($pr_popular) && !empty($pr_popular)): ?>
              <?php foreach($pr_popular as $v): ?>
                <article class="pr excerpt">
                    <div class="post-date-ribbon">
                        <div class="corner"></div><u>Giá:</u> <?php echo e(_formatPrice($v['price'])); ?>

                    </div>
                    <header>
                    <a href="<?php echo e(_getProductLink($v['slug'])); ?>" title="<?php echo e(isset($v['title']) ? $v['title'] : ''); ?>">
                        <div class="featured-thumbnail">
                            <img src="<?php echo e(isset($v['thumbnail']) ? $v['thumbnail'] : ''); ?>" class="attachment-ribbon-lite-featured size-ribbon-lite-featured wp-post-image" alt="<?php echo e(isset($v['title']) ? $v['title'] : ''); ?>" title="<?php echo e(isset($v['title']) ? $v['title'] : ''); ?>" srcset="" sizes="(max-width: 150px) 100vw, 150px">
                        </div>
                    </a>
                    <h2 class="title text-center">
                        <a href="<?php echo e(_getProductLink($v['slug'])); ?>" title="<?php echo e(isset($v['title']) ? $v['title'] : ''); ?>" rel="bookmark"><?php echo e(isset($v['title']) ? $v['title'] : ''); ?></a>
                    </h2>
                    </header><!--.header-->
                    <div class="clearfix"></div>
                </article>
              <?php endforeach; ?>
            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>