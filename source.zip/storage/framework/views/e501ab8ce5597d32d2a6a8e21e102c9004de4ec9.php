<?php if($nodes->count()): ?>
    <ul class="list-unstyled">
        <?php foreach($nodes as $key => $row): ?>
            <li>
                <label>
                    <input type="checkbox"
                           <?php echo e(((in_array($row->id, $checkedNodes)) ? 'checked="checked"' : '')); ?> name="category_ids[]"
                           value="<?php echo e(isset($row->id) ? $row->id : ''); ?>">
                    <?php echo e(isset($row->title) ? $row->title : ''); ?>

                </label>
                <?php echo $__env->make('admin._partials._categories', ['nodes' => $row->child()->get(), 'checkedNodes' => $checkedNodes], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>