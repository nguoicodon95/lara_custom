<li data-position="<?php echo e(isset($key) ? $key : ''); ?>">
    <div class="col-xs-3">
        <span class="field-label"><?php echo e(isset($repeaterField[$currentRepeaterKey]->title) ? $repeaterField[$currentRepeaterKey]->title : ''); ?></span>
        <br>
        <span class="field-instructions"><?php echo e(isset($repeaterField[$currentRepeaterKey]->instructions) ? $repeaterField[$currentRepeaterKey]->instructions : ''); ?></span>
    </div>
    <div class="col-xs-9">
        <?php echo $object->initRepeaterInputItem($subField, $options, $current); ?>

    </div>
    <div class="clearfix"></div>
</li>