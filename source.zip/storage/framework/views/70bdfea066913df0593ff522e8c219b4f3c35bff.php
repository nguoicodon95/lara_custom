<?php $__env->startSection('page-toolbar'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
  <script type="text/javascript">
      // store the currently selected tab in the hash value
      $("ul.nav-tabs > li > a").on("shown.bs.tab", function(e) {
          var id = $(e.target).attr("href").substr(1);
          window.location.hash = id;
      });

      // on load of the page: switch to the currently selected tab
      var hash = window.location.hash;
          $('#o_tab a[href="' + hash + '"]').tab('show');
  </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $status = '<span class="label label-primary label-sm">Chưa giải quyết</span>';
        if ($transaction->status != 0 && $transaction->status != 2 && $transaction->status != 3) {
            $status = '<span class="label label-success label-sm">Đã giải quyết</span>';
        } else if($transaction->status != 0 && $transaction->status != 1 && $transaction->status != 3) {
            $status = '<span class="label label-warning label-sm">Giữ lại</span>';
        } else if($transaction->status != 0 && $transaction->status != 1 && $transaction->status != 2) {
            $status = '<span class="label label-danger label-sm">Hủy</span>';
        }
    ?>
    <div class="row">
        <div class="col-lg-12">
            <!-- Begin: life time stats -->
            <div class="portlet light">
                <div class="portlet-title">
                    <div class="caption">
                        <i class="icon-basket font-green-sharp"></i>
                        <span class="caption-subject font-green-sharp bold uppercase">
                        Order #<?php echo e($transaction->id); ?> </span>
                        <span class="caption-helper"><?php echo e($transaction->created_at); ?></span>
                    </div>
                    <div class="actions">
                        <a href="javascript:;" class="btn btn-default btn-circle">
                        <i class="fa fa-angle-left"></i>
                        <span class="hidden-480">
                        Back </span>
                        </a>
                    </div>
                </div>
                <div class="portlet-body">
                    <div class="tabbable">
                        <ul class="nav nav-tabs nav-tabs-lg" id="o_tab">
                            <li class="active">
                                <a href="#detail-order" data-toggle="tab">
                                Thông tin đặt hàng </a>
                            </li>
                            <li>
                                <a href="#update-order" data-toggle="tab">
                                Cập nhật đơn đặt hàng </a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="detail-order">
                                <div class="row">
                                    <div class="col-md-6 col-sm-12">
                                        <div class="portlet yellow-crusta box">
                                            <div class="portlet-title">
                                                <div class="caption">
                                                    <i class="fa fa-cogs"></i>Order Details
                                                </div>
                                                <div class="actions">
                                                </div>
                                            </div>
                                            <div class="portlet-body">
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                         Order #:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e($transaction->id); ?>

                                                    </div>
                                                </div>
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                        Order Date & Time:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e($transaction->created_at); ?>

                                                    </div>
                                                </div>
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                         Order Status:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo $status; ?>

                                                    </div>
                                                </div>
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                        Grand Total:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e(_formatPrice($transaction->amount)); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-sm-12">
                                        <div class="portlet blue-hoki box">
                                            <div class="portlet-title">
                                                <div class="caption">
                                                    <i class="fa fa-cogs"></i>Customer Information
                                                </div>
                                                <!-- <div class="actions">
                                                    <a href="javascript:;" class="btn btn-default btn-sm">
                                                    <i class="fa fa-pencil"></i> Edit </a>
                                                </div> -->
                                            </div>
                                            <div class="portlet-body">
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                        Customer Name:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e($transaction->name); ?>

                                                    </div>
                                                </div>
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                        Email:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e($transaction->email); ?>

                                                    </div>
                                                </div>
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                        Phone Number:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e($transaction->phone); ?>

                                                    </div>
                                                </div>
                                                <div class="row static-info">
                                                    <div class="col-md-5 name">
                                                        Note:
                                                    </div>
                                                    <div class="col-md-7 value">
                                                        <?php echo e(!is_null(trim($transaction->messages)) ? $transaction->messages : '-'); ?>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-12 col-sm-12">
                                        <div class="portlet grey-cascade box">
                                            <div class="portlet-title">
                                                <div class="caption">
                                                    <i class="fa fa-cogs"></i>Shopping Cart
                                                </div>
                                                <!-- <div class="actions">
                                                    <a href="javascript:;" class="btn btn-default btn-sm">
                                                    <i class="fa fa-pencil"></i> Edit </a>
                                                </div> -->
                                            </div>
                                            <div class="portlet-body">
                                                <div class="table-responsive">
                                                    <table class="table table-hover table-bordered table-striped">
                                                    <thead>
                                                    <tr>
                                                        <th>
                                                             Product
                                                        </th>
                                                        <th>
                                                             Price
                                                        </th>
                                                        <th>
                                                             Quantity
                                                        </th>
                                                        <th>
                                                             Total
                                                        </th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php foreach($transaction->orders as $order): ?>
                                                    <?php $p = $order->products; ?>
                                                    <?php $row = $p->productContent; ?>
                                                    <tr>
                                                        <td>
                                                            <a href="<?php echo e(_getProductLink($row->slug)); ?>" target="_blank">
                                                            <?php echo e($row->title); ?> </a>
                                                        </td>
                                                        <td>
                                                            <span class="label label-sm label-success">
                                                            <?php echo e(_formatPrice($row->price)); ?>

                                                        </td>

                                                        <td>
                                                            <?php echo e($order->qty); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e(_formatPrice($order->amount)); ?>

                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                    </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                    </div>
                                    <div class="col-md-6">
                                        <div class="well">
                                            <div class="row static-info align-reverse">
                                                <div class="col-md-8 name">
                                                     Total:
                                                </div>
                                                <div class="col-md-3 value">
                                                    <?php echo e(_formatPrice($transaction->amount)); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane" id="update-order">
                                <div class="col-md-12">
                                    <form action="" method="post">
                                        <?php echo e(csrf_field()); ?>

                                        <table width="100%">
                                            <tr>
                                                <td width="20%">
                                                    <label><b>Trạng thái đơn hàng</b></label>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <select name="status" class="table-group-action-input form-control input-inline input-small input-sm">
                                                            <option value="">Select...</option>
                                                            <option value="0" <?php echo e($transaction->status == 0 ? 'selected' : ''); ?>>Chưa giải quyết</option>
                                                            <option value="1" <?php echo e($transaction->status == 1 ? 'selected' : ''); ?>>Đã giải quyết</option>
                                                            <option value="2" <?php echo e($transaction->status == 2 ? 'selected' : ''); ?>>Giữ lại</option>
                                                            <option value="3" <?php echo e($transaction->status == 3 ? 'selected' : ''); ?>>Hủy</option>
                                                        </select>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td width="20%">
                                                    <label><b>Ghi chú đơn hàng</b></label>
                                                </td>
                                                <td>
                                                    <div class="form-group">
                                                        <textarea name="note" class="form-control" rows="5"><?php echo e(isset($transaction->note) ? $transaction->note : ''); ?></textarea>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan=2>
                                                    <label class="pull-left">
                                                        <input type="checkbox" name="sent_mail">Gửi email đến khách hàng
                                                    </label>
                                                    <button class="btn btn-sm green pull-right">
                                                        <i class="fa fa-check"></i> Cập nhật
                                                    </button>
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End: life time stats -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>