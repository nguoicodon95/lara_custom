<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .article {
            margin-bottom: 15px;
        }
        .article img {
            max-width: 100%;
        }
        .pr {
            padding: 0 3px;
        }
        .article a.title {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block;
        }
        .thumbnail {
            padding: 0;
            border-radius: 0;
            margin-bottom: 10px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script>
        $('input[name=sortby], input[name=price]').change(function (e) {
            $('#form_filter').submit();
        })

        function updateQueryStringParameter(uri, key, value) {
            var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
            var separator = uri.indexOf('?') !== -1 ? "&" : "?";
            if (uri.match(re)) {
                return uri.replace(re, '$1' + key + "=" + value + '$2');
            }
            else {
                return uri + separator + key + "=" + value
            }
        }

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="products_grid p_block_home">
        <div class="row">
            <?php $count = $products->count() + $posts->count(); ?>
            <h4 class="group_title"><span>Có <strong><?php echo e($count); ?></strong> kết quả tìm kiếm <strong>"<?php echo e(Request::get('q')); ?>"</strong></span></h4>
            <?php if(isset($products)): ?>
                <?php $__empty_1 = true; foreach($products as $p): $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <div class="grid">
                            <div class="item">
                                <div class="thumb">
                                    <a class="product-image" href="<?php echo e(_getProductLink($p['slug'])); ?>" title="<?php echo e($p['title']); ?>">
                                        <img class="product-img" src="<?php echo e($p['thumbnail']); ?>" alt="<?php echo e($p['title']); ?>" title="<?php echo e($p['title']); ?>"/>
                                    </a>
                                </div>
                                <h3>
                                    <a href="<?php echo e(_getProductLink($p['slug'])); ?>" title="<?php echo e($p['title']); ?>"><?php echo e($p['title']); ?></a>
                                </h3>
                                <p class="sku">Mã SP: <?php echo e($p->product->sku); ?></p>

                                <div class="price-box">
                                    <span class="regular-price">
                                        <?php if($p['old_price'] != 0): ?>
                                        <span class="old-price"><?php echo e(_formatPrice($p['old_price'])); ?></span>
                                        <?php endif; ?>
                                        <span class="price"><?php echo e(_formatPrice($p['price'])); ?></span>
                                    </span>
                                </div>

                                <a class="linkdetail" href="<?php echo e(_getAddToCartLink($p->id)); ?>">Đặt hàng</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; if ($__empty_1): ?>
                    <p>Hiện tìm thấy sản phẩm nào</p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php if(isset($posts) && !empty($posts)): ?>
    <div class="posts">
        <h2 class="group_title"><span>Bài viết</span></h2>
        <div class="">
            <div class="row">
            <?php foreach($posts as $post): ?>
                <div class="col-md-4 col-sm-6 article">
                    <div class="col-md-3 thumbnail">
                        <a href="<?php echo e(_getPostLink($post->slug)); ?>" title="<?php echo e($post->title); ?>">
                            <img src="<?php echo e($post->thumbnail); ?>" alt="<?php echo e($post->title); ?>" title="<?php echo e($post->title); ?>">
                        </a>
                    </div>
                    <div class="col-md-9 pr">
                        <a href="<?php echo e(_getPostLink($post->slug)); ?>" class="title" title="<?php echo e($post->title); ?>"><?php echo e($post->title); ?></a>
                        <div class="desc">
                            <?php echo str_limit($post->description, 55); ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="clearfix"></div>
    <!--div align="center">
        <?php /* !! $all_product->setPath(asset(Request::path()))->appends(Request::query())->render() !!} */ ?>
    </div-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>