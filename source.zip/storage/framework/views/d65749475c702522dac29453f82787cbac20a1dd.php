<!-- BEGIN HEADER INNER -->
<div class="page-header-inner ">
    <!-- BEGIN LOGO -->
    <div class="page-logo">
        <a href="/">
            <img src="/admin/theme/images/logo.png" alt="logo" class="logo-default"/>
        </a>
    </div>
    <!-- END LOGO -->
    <!-- BEGIN RESPONSIVE MENU TOGGLER -->
    <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>
    <!-- END RESPONSIVE MENU TOGGLER -->
    <!-- BEGIN TOP NAVIGATION MENU -->
    <div class="top-menu">
        <ul class="nav navbar-nav pull-right">
            <?php if(isset($unreadTransCount) && $unreadTransCount): ?>
            <li class="dropdown dropdown-extended dropdown-notification dropdown-dark" id="header_notification_bar">
                <a href="<?php echo e('/'.$adminCpAccess.'/orders'); ?>" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                <i class="icon-bell"></i>
                <span class="badge badge-success"><?php echo e($unreadTransCount); ?></span>
                </a>
                <ul class="dropdown-menu">
                    <li class="external">
                        <h3><span class="bold"><?php echo e($unreadTransCount); ?> đơn đặt hàng</span> chưa xem</h3>
                        <a href="<?php echo e('/'.$adminCpAccess.'/orders'); ?>">view all</a>
                    </li>
                    <li>
                        <div class="slimScrollDiv">
                            <?php if(isset($lists) && $lists): ?>
                            <ul class="dropdown-menu-list scroller" style="max-height: 250px; overflow-y: auto; width: auto;" data-handle-color="#637283" data-initialized="1">
                                <?php foreach($lists as $l): ?>
                                <li>
                                    <a href="<?php echo e('/'.$adminCpAccess.'/orders/detail/'.$l->id); ?>">
                                    <span class="time"><?php echo e($l->created_at->diffForHumans()); ?></span>
                                    <span class="details">
                                    <span class="label label-sm label-icon label-warning">
                                    <i class="fa fa-bell-o"></i>
                                    </span> <?php echo e($l->name .' - '. _formatPrice($l->amount)); ?> </span>
                                    </a>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                            <?php endif; ?>
                        </div>
                    </li>
                </ul>
            </li>
            <?php endif; ?>
            <?php if(isset($unreadMailCount) && $unreadMailCount): ?>
                <li class="dropdown dropdown-extended dropdown-inbox" id="header_inbox_bar">
                    <a title="Bạn có <?php echo e($unreadMailCount); ?> thư chưa đọc trong inbox" href="<?php echo e('/'.$adminCpAccess.'/contacts'); ?>" class="dropdown-toggle" style="padding-right: 10px;">
                        <i class="icon-envelope-open"></i>
                        <span class="badge badge-default"><?php echo e($unreadMailCount); ?></span>
                    </a>
                </li>
            <?php endif; ?>
            <li class="dropdown dropdown-extended dropdown-user dropdown-dark dropdown-notification" id="header_notification_bar">
                <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                    <span class="username"><i class="fa fa-plus"></i> Add new</span>
                </a>
                <ul class="dropdown-menu dropdown-menu-default">
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/pages/edit/0">
                            <i class="fa fa-tasks"></i> Page
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/posts/edit/0">
                            <i class="icon-layers"></i> Post
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/categories/edit/0">
                            <i class="fa fa-sitemap"></i> Category
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/products/edit/0">
                            <i class="fa fa-cubes"></i> Product
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/product-categories/edit/0">
                            <i class="fa fa-sitemap"></i> Product category
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/coupons/edit/0">
                            <i class="fa fa-code"></i> Coupon
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/brands/edit/0">
                            <i class="fa fa-umbrella"></i> Brands
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/custom-fields/edit/0">
                            <i class="fa fa-edit"></i> Custom field
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/users/edit/0">
                            <i class="icon-users"></i> User
                        </a>
                    </li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/admin-users/edit/0">
                            <i class="icon-users"></i> Admin user
                        </a>
                    </li>
                </ul>
            </li>
            <li class="dropdown dropdown-user dropdown-dark">
                <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                    <img alt="" class="img-circle" src="/admin/theme/assets/layouts/layout/img/avatar3_small.jpg">
                    <span class="username username-hide-on-mobile"><?php echo e($loggedInAdminUser->username); ?></span>
                    <i class="fa fa-angle-down"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-default">
                    <li>
                        <a href="/<?php echo e($adminCpAccess); ?>/admin-users/edit/<?php echo e($loggedInAdminUser->id); ?>">
                            <i class="icon-key"></i> Change password
                        </a>
                    </li>
                    <li class="divider"></li>
                    <li>
                        <a href="/<?php echo e($adminCpAccess.'/auth/logout'); ?>">
                            <i class="icon-logout"></i> Log Out
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <!-- END TOP NAVIGATION MENU -->
</div>
<!-- END HEADER INNER -->
