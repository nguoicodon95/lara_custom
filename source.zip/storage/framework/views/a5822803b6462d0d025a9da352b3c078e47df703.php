<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="/js/pagecategorypr.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-init'); ?>
    <script type="text/javascript">
        FilterJs.Elemchange('input[name=price]', 'price')
        FilterJs.Elemchange('input[name=sortby]', 'sortby')
        FilterJs.Elemchange('input[name=brands]', 'brands')
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="products_grid p_block_category">
        <div class="col-md-3 filterbx hidden-xs">
            <form action="" method="get" id="form_filter">
                <div class="sort-by">
                    <h2 class="group_title"><span>Lựa chọn</span></h2>
                    <div class="asc-sort">
                        <input type="radio" name="sortby" id="sortasc" class="radio" value="asc" <?php echo e(isset($sort_by) && ($sort_by == 'asc') ? 'checked' : null); ?>/>
                        <label for="sortasc">Giá từ thấp đến cao</label>
                    </div>
                    <div class="clearfix"></div>
                    <div class="desc-sort">
                        <input type="radio" name="sortby" id="sortdesc" class="radio" value="desc" <?php echo e(isset($sort_by) && ($sort_by == 'desc') ? 'checked' : null); ?>/>
                        <label for="sortdesc">Giá từ cao đến thấp</label>
                    </div>
                    <div class="clearfix"></div>
                </div>

                <div class="brands">
                    <h2 class="group_title"><span>Nhà sản xuất</span></h2>
                    <?php if(isset($brands) && !empty($brands)): ?>
                        <?php foreach($brands as $brand): ?>
                          <div class="funkyradio-danger">
                              <input type="checkbox" name="brands" id="brand<?php echo e($brand->id); ?>" value="<?php echo e($brand->id); ?>" <?php echo e(isset($f_brand) && in_array($brand->id, $f_brand) ? 'checked' : ''); ?>/>
                              <label for="brand<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?> <span class="badge"><?php echo e($brand->product()->count()); ?></span></label>
                          </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <?php if(isset($rangePrice)): ?>
                <div class="find sort-by">
                    <h2 class="group_title"><span>Tìm kiếm theo giá</span></h2>
                    <a class="toggle">-</a>
                    <div class="asc-sort">
                        <input type="radio" name="price" id="default_pr" class="radio" value="default" <?php echo e(!isset($price_filter) || ($price_filter == 'default')  ? 'checked' : null); ?>/>
                        <label for="default_pr">Mặc định</label>
                    </div>
                    <?php $__empty_1 = true; foreach($rangePrice as $key => $price): $__empty_1 = false; ?>
                    <?php
                        $value = (string) $price['min'].'-'.$price['max'];
                    ?>
                    <div class="asc-sort">
                        <input type="radio" name="price" id="<?php echo e($key); ?>" class="radio" value="<?php echo e($value); ?>" <?php echo e(isset($price_filter) && ($price_filter == $value) ? 'checked' : null); ?>/>
                        <label for="<?php echo e($key); ?>" title="<?php echo e(_formatPrice($price['min']). ' - ' ._formatPrice($price['max'])); ?>"><?php echo e(_formatPrice($price['min']). ' - ' ._formatPrice($price['max'])); ?></label>
                    </div>
                    <div class="clearfix"></div>
                    <?php endforeach; if ($__empty_1): ?>
                        <p>Giá cố định</p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </form>
        </div>
        <div class="col-md-9 mb-prbx">
            <div class="prbx">
            <?php if(isset($all_product)): ?>
                <?php $__empty_1 = true; foreach($all_product as $p): $__empty_1 = false; ?>
                <div class="col-md-4 grid">
                    <div class="item">
                        <div class="thumb">
                            <a class="product-image" href="<?php echo e(_getProductLink($p->slug)); ?>" title="<?php echo e($p->title); ?>">
                                <img class="product-img" src="<?php echo e($p->thumbnail); ?>" alt="<?php echo e($p->title); ?>" />
                            </a>
                        </div>
                        <h3>
                            <a href="<?php echo e(_getProductLink($p->slug)); ?>" title="<?php echo e($p->title); ?>"><?php echo ($p->title); ?></a>
                        </h3>
                        <div class="price-box">
                            <span class="regular-price">
                                <?php if($p->old_price != 0): ?>
                                <span class="old-price"><s><?php echo e(_formatPrice($p->old_price)); ?></s></span>
                                <?php endif; ?>
                                <span class="price"><?php echo e(_formatPrice($p->price)); ?></span>
                            </span>
                        </div>
                        <div align="left" class="bgr">
                            <a class="addcart btn btn-danger btn-sm" href="<?php echo e(_getAddToCartLink($p->content_id)); ?>">Đặt hàng</a>
                            <a class="detail btn btn-info btn-sm" href="<?php echo e(_getProductLink($p->slug)); ?>">Xem chi tiết</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; if ($__empty_1): ?>
                    <p>Hiện tại chưa có sản phẩm nào</p>
                <?php endif; ?>
            <?php endif; ?>
                <div class="clearfix"></div>
            </div>
            <div align="center">
                <?php echo $all_product->setPath(asset(Request::path()))->appends(Request::query())->render(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front._master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>