<?php
return [
    'error' => 'کپچا اشتباه است',
];
