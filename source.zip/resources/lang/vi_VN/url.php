<?php

return [
    'post' => 'bai-viet',
    'category' => 'danh-muc',
    'product' => 'san-pham',
    'productCategory' => 'danh-muc-san-pham',
];