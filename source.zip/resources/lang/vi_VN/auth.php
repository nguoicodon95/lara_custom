<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Thông tin đăng nhập không khớp với hồ sơ của chúng tôi.',
    'throttle' => 'Bạn đã thử đăng nhập quá nhiều. Thử đăng nhập lại sau :seconds giây.',

];
