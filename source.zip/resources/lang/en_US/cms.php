<?php

return [
    'requestCompleted' => 'Request completed',
    'requestNotCompleted' => 'Request not completed',

    'page' => 'Page',
];