<?php

return [
    'error' => 'Wrong captcha',
];