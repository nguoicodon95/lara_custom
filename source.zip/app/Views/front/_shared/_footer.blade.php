<div class="mobile">
    <div id="bottom_hotline" class="pull-left">
    </div>
    <div id="bottom_nav" class="pull-left">
    </div>
</div>
<div id="footer_contain">
    <div class="container">
        <div class="list_items">
            <h4>Hỗ trợ mua h&agrave;ng</h4>
            <ul>
                <li><a href="huong-dan-mua-hang.html">Hướng dẫn mua h&agrave;ng</a></li>
                <li><a href="huong-dan-do-size-nhan.html">Hướng dẫn đo size nhẫn</a></li>
                <li><a href="phuong-thuc-thanh-toan.html">Phương thức thanh to&aacute;n</a></li>
                <li><a href="phuong-thuc-van-chuyen.html">Phương thức vận chuyển</a></li>
                <li><span><a title="Tra cứu đơn h&agrave;ng - Lợi &iacute;ch th&agrave;nh vi&ecirc;n" href="tra-cuu-don-hang-loi-ich-thanh-vien.html" target="_blank">Tra cứu đơn h&agrave;ng - Lợi &iacute;ch th&agrave;nh vi&ecirc;n</a></span></li>
                <li><a title="Chế độ bảo h&agrave;nh" href="che-do-bao-hanh.html" target="_blank">Chế độ bảo h&agrave;nh</a></li>
                <li><a title="Chế độ thu đổi" href="che-do-thu-doi.html" target="_blank">Chế độ thu đổi</a></li>
                <li><a href="chinh-sach-mua-hang-online.html" target="_blank">Mua Online nhận ngay gi&aacute; tốt</a></li>
            </ul>
        </div>
        <div class="list_items">
            <h4>Cẩm nang sử dụng</h4>
            <ul>
                <li><a title="Cẩm nang sử dụng Kim Cương" href="cam-nang-su-dung-kim-cuong.html" target="_blank">Trang sức Kim Cương</a></li>
                <li><a title="Cẩm nang sử dụng Ngọc Trai" href="cam-nang-su-dung-ngoc-trai.html" target="_blank">Trang sức Ngọc Trai</a></li>
                <li><a title="Cẩm nang sử dụng Đ&aacute; Qu&yacute;" href="cam-nang-su-dung-da-quy.html" target="_blank">Trang sức Đ&aacute; Qu&yacute;</a></li>
                <li><a title="Cẩm nang sử dụng ECZ" href="cam-nang-su-dung-ecz.html" target="_blank">Trang sức ECZ</a></li>
                <li><a title="Cẩm nang sử dụng trang sức theo th&aacute;ng sinh" href="cam-nang-su-dung-trang-suc-theo-thang-sinh.html" target="_blank">Trang sức theo th&aacute;ng sinh</a></li>
                <li><a title="Cẩm nang sử dụng trang sức theo phong thủy" href="cam-nang-su-dung-trang-suc-theo-phong-thuy.html" target="_blank">Trang sức theo phong thuỷ</a></li>
                <li><a title="Cẩm nang sử dụng Đồng Hồ" href="cam-nang-su-dung-dong-ho.html" target="_blank">Đồng Hồ</a></li>
                <li><a title="Hướng dẫn sử dụng trang sức" href="huong-dan-su-dung-trang-suc.html" target="_blank">Hướng dẫn sử dụng trang sức</a></li>
            </ul>
        </div>
        <div class="list_items">
            <h4>Về ch&uacute;ng t&ocirc;i</h4>
            <ul>
                <li><a href="http://pnj.com.vn/he-thong-cua-hang" target="_blank">Hệ thống cửa h&agrave;ng</a></li>
                <li><a href="http://pnj.com.vn/tin-tuc" target="_blank">Tin tức</a></li>
                <li><a title="Gắn kết y&ecirc;u thương" href="tin-khuyen-mai/index.html" target="_blank">Tin khuyến m&atilde;i</a></li>
                <li><a href="contacts.html">Li&ecirc;n hệ</a></li>
                <li><a title="PNJ Q&amp;A" href="pnjqa.html" target="_blank">FAQs</a></li>
            </ul>
        </div>
        <div class="list_items">
            <h4>Hỗ trợ thanh to&aacute;n</h4>
            <ul>
                <li>
                </li>
            </ul>
            <h4>Được chứng nhận</h4>
            <ul>
                <li></li>
            </ul>
        </div>
        <div class="list_items">
            <h4>Li&ecirc;n kết với ch&uacute;ng t&ocirc;i</h4>
            <ul>
                <li>
                    <div class="fb-page" data-href="https://www.facebook.com" data-width="200" data-height="250" data-small-header="true" data-adapt-container-width="false" data-hide-cover="false" data-show-facepile="false">
                        <blockquote class="fb-xfbml-parse-ignore" cite="https://www.facebook.com">
                            <a href="https://www.facebook.com">Fan page</a>
                        </blockquote>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="copyright">
    <div class="container">
        <div id="copyright" class="pull-left">© 2016 ABC</div>
        <div class="clearfix"></div>
    </div>
</div>