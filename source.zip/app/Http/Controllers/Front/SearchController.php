<?php

namespace App\Http\Controllers\Front;

use Illuminate\Http\Request;

use App\Models\Product;
use App\Models\ProductContent;
use App\Models\Page;
use App\Models\Post;
use App\Models\Category;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SearchController extends BaseFrontController
{
    public function autocomplete (Request $request) {
        print('Chức năng đang cập nhật. <a href="/"><u>Quay lại</u></a>');die;
        $q = $request->q;
        // $a[] = Product::SearchByKeyword($param)->get();
        $a = ProductContent::SearchByKeyword($q)->get();
        // $a[] = Page::SearchByKeyword($param)->get();
        // $a[] = Post::SearchByKeyword($param)->get();
        // $a[] = Category::SearchByKeyword($param)->get();
        dd($a);
        // return $a;
    }
}
